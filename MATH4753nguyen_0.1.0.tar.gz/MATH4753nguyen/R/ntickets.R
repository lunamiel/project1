#' Optimal number of tickets to sell
#'
#' Finds how many tickets an airline should sell for a flight with \code{N}
#' seats so that the chance of the plane being overbooked is \code{gamma}.
#' It does this two ways: using the binomial distribution (discrete) and using
#' the normal approximation with a continuity correction (continuous). It also
#' draws the objective function against n for both cases.
#'
#' @param N number of seats on the flight
#' @param gamma probability the plane is truly overbooked (more people show up
#'   than there are seats)
#' @param p probability a ticket holder shows up
#'
#' @return A named list with \code{nd} (discrete answer), \code{nc}
#'   (normal approximation answer), \code{N}, \code{p} and \code{gamma}.
#'   The list is printed and returned invisibly.
#' @export
#'
#' @examples
#' ntickets(N = 400, gamma = 0.02, p = 0.95)
ntickets <- function(N, gamma, p) {
  # values of n to search, from N up to 10% more than N
  n <- seq(N, floor(N + N / 10), by = 1)

  # discrete objective: 1 - gamma - P(X <= N) where X ~ Bin(n, p)
  objd <- 1 - gamma - stats::pbinom(q = N, size = n, prob = p)
  # n that makes the objective closest to 0
  nd <- n[which.min(abs(objd))]

  # continuous objective with normal approx and continuity correction
  objc <- function(n) {
    1 - gamma - stats::pnorm(N + 0.5, mean = n * p, sd = sqrt(n * p * (1 - p)))
  }
  # root of the continuous objective
  nc <- stats::uniroot(objc, interval = c(N, floor(N + N / 10)))$root

  # plot 1: discrete case
  graphics::plot(n, objd, type = "b", pch = 21, bg = "#7FA86A",
                 xlab = "n", ylab = "Objective",
                 main = paste0("Objective Vs n to find optimal tickets sold\n(",
                               nd, ") gamma = ", gamma, " N = ", N, " discrete"))
  graphics::abline(h = 0, col = "red", lwd = 2)
  graphics::abline(v = nd, col = "red", lwd = 2)

  # plot 2: continuous case
  nn <- seq(N, floor(N + N / 10), length.out = 500)
  graphics::plot(nn, objc(nn), type = "l", lwd = 3, col = "#4E7A3E",
                 xlab = "n", ylab = "Objective",
                 main = paste0("Objective Vs n to find optimal tickets sold\n(",
                               round(nc, 4), ") gamma = ", gamma, " N = ", N,
                               " continuous"))
  graphics::abline(h = 0, col = "blue", lwd = 2)
  graphics::abline(v = nc, col = "blue", lwd = 2)

  # named list
  res <- list(nd = nd, nc = nc, N = N, p = p, gamma = gamma)
  print(res)
  invisible(res)
}
